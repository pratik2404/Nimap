package com.ex.CurdOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
